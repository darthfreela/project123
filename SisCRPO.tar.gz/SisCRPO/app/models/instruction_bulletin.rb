class InstructionBulletin < ActiveRecord::Base
end
