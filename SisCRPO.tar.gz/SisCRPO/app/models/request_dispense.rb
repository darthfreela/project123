class RequestDispense < ActiveRecord::Base
  belongs_to :user
 
end
