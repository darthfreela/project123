class ImportFile < ActiveRecord::Base
end
