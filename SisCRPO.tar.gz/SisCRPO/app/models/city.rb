class City < ActiveRecord::Base
end
