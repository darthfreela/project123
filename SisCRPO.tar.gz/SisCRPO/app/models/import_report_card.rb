class ImportReportCard < ActiveRecord::Base
end
