class ReportOvertimeSupplementation < ActiveRecord::Base
end
