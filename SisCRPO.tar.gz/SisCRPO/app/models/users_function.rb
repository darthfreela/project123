class UsersFunction < ActiveRecord::Base
    has_many :users
end
