class SubstituicaoTemporarium < ActiveRecord::Base
end
