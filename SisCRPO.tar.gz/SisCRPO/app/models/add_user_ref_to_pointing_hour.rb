class AddUserRefToPointingHour < ActiveRecord::Base
  belongs_to :user
end
