class ImportedFile < ActiveRecord::Base
end
