module TraineesHelper
end
