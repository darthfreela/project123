require 'rails_helper'

RSpec.describe ImportReportCard, type: :model do
  pending "add some examples to (or delete) #{__FILE__}"
end
