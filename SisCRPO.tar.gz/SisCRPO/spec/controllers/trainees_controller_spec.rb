require 'rails_helper'

RSpec.describe TraineesController, type: :controller do

end
