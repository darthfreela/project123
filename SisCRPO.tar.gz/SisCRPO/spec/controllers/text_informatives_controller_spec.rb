require 'rails_helper'

RSpec.describe TextInformativesController, type: :controller do

end
