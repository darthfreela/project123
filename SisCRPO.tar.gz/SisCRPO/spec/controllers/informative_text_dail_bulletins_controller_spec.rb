require 'rails_helper'

RSpec.describe InformativeTextDailBulletinsController, type: :controller do

end
