require 'rails_helper'

RSpec.describe ExtraHourDistributionsController, type: :controller do

end
