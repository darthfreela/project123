require 'rails_helper'

RSpec.describe SolicitationsController, type: :controller do

end
