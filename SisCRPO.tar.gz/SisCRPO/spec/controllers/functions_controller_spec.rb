require 'rails_helper'

RSpec.describe FunctionsController, type: :controller do
  
end
