require 'rails_helper'

RSpec.describe UniformsController, type: :controller do

end
