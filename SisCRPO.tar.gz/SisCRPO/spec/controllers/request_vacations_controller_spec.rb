require 'rails_helper'

RSpec.describe RequestVacationsController, type: :controller do

end
