class CreateTables < ActiveRecord::Migration
  def change
    create_table :tables do |t|
    end
  end
end
